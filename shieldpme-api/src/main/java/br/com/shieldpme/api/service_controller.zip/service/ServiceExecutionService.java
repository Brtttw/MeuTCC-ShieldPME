package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service; import br.com.shieldpme.api.entity.ServiceExecution; import br.com.shieldpme.api.repository.ServiceExecutionRepository;
@Service public class ServiceExecutionService extends AbstractCrudService<ServiceExecution> { public ServiceExecutionService(ServiceExecutionRepository repository){super(repository);} }
