package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.ServiceFrequency;
import br.com.shieldpme.api.repository.ServiceFrequencyRepository;
@Service public class ContractServiceFrequencyService extends AbstractCrudService<ServiceFrequency> {
 public ContractServiceFrequencyService(ServiceFrequencyRepository repository) { super(repository); }
}
