package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service; import br.com.shieldpme.api.entity.ExecutionAssignment; import br.com.shieldpme.api.repository.ExecutionAssaignmentRepository;
@Service public class ExecutionAssignmentService extends AbstractCrudService<ExecutionAssignment> { public ExecutionAssignmentService(ExecutionAssaignmentRepository repository){super(repository);} }
