package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.SystemSetting;
import br.com.shieldpme.api.repository.SystemSettingsRepository;
@Service public class SystemSettingService extends AbstractCrudService<SystemSetting> {
 public SystemSettingService(SystemSettingsRepository repository) { super(repository); }
}
