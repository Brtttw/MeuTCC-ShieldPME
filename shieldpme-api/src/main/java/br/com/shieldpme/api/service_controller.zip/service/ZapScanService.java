package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
/** Placeholder intencional: integração OWASP ZAP será implementada com o usuário. */
@Service public class ZapScanService { /* TODO: iniciar scan, consultar status e persistir resultados. */ }
