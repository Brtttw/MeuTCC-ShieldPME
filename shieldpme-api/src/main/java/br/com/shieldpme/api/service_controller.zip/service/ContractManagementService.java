package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.Contract;
import br.com.shieldpme.api.repository.ContractRepository;
@Service public class ContractManagementService extends AbstractCrudService<Contract> {
 public ContractManagementService(ContractRepository repository){super(repository);}
}
