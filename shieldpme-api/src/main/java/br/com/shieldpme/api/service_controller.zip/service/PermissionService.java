package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.Permission;
import br.com.shieldpme.api.repository.PermissionRepository;
@Service public class PermissionService extends AbstractCrudService<Permission> {
 public PermissionService(PermissionRepository repository) { super(repository); }
}
