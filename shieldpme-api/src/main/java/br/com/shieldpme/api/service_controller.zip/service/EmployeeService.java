package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.Employee;
import br.com.shieldpme.api.repository.EmployeeRepository;
@Service public class EmployeeService extends AbstractCrudService<Employee> {
 public EmployeeService(EmployeeRepository repository) { super(repository); }
}
