package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service; import br.com.shieldpme.api.entity.ContractService; import br.com.shieldpme.api.repository.ContractServiceRepository;
@Service public class ContractServiceService extends AbstractCrudService<ContractService> { public ContractServiceService(ContractServiceRepository repository){super(repository);} }
