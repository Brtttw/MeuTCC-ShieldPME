package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
@Service public class AuthenticationService { /* TODO: implementar com DTOs, PasswordEncoder e Spring Security. */ }
