package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.Report;
import br.com.shieldpme.api.repository.ReportRepository;
@Service public class ReportService extends AbstractCrudService<Report> {
 public ReportService(ReportRepository repository) { super(repository); }
}
