package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.ServiceOffering;
import br.com.shieldpme.api.repository.ServiceOfferingRepository;
@Service public class ContractServiceOfferingService extends AbstractCrudService<ServiceOffering> {
 public ContractServiceOfferingService(ServiceOfferingRepository repository) { super(repository); }
}
