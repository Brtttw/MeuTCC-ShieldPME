package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service; import br.com.shieldpme.api.entity.ReportSection; import br.com.shieldpme.api.repository.ReportSectionRepository;
@Service public class ReportSectionService extends AbstractCrudService<ReportSection> { public ReportSectionService(ReportSectionRepository repository){super(repository);} }
