package br.com.shieldpme.api.service;
import org.springframework.stereotype.Service;
import br.com.shieldpme.api.entity.Role;
import br.com.shieldpme.api.repository.RoleRepository;
@Service public class RoleService extends AbstractCrudService<Role> {
 public RoleService(RoleRepository repository) { super(repository); }
}
